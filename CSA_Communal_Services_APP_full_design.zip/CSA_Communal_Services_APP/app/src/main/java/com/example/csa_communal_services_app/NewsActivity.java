package com.example.csa_communal_services_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NewsActivity extends AppCompatActivity {

    private Button buttonLog, buttonReg, buttonAddWork, buttonAddNews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        buttonReg = (Button) findViewById(R.id.main_reg_btn);
        buttonLog = (Button) findViewById(R.id.main_log_btn);

        buttonAddWork = (Button) findViewById(R.id.add_work);
        buttonAddNews = (Button) findViewById(R.id.add_news_admin);

        buttonLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LoginIntent = new Intent(NewsActivity.this, LoginActivity.class);
                startActivity(LoginIntent);
            }
        });

        buttonReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent RegistrationIntent = new Intent(NewsActivity.this, RegistrationActivity.class);
                startActivity(RegistrationIntent);
            }
        });

        buttonAddWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent AddWorkIntent = new Intent(NewsActivity.this, AddWorkActivity.class);
                startActivity(AddWorkIntent);
            }
        });

        buttonAddNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent AddNewsIntent = new Intent(NewsActivity.this, AddNewsActivity.class);
                startActivity(AddNewsIntent);
            }
        });
    }
}