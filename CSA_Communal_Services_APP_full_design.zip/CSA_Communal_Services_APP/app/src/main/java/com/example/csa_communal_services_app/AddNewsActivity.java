package com.example.csa_communal_services_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AddNewsActivity extends AppCompatActivity {

    private Button buttonAddNews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_news);

        buttonAddNews = (Button) findViewById(R.id.add_news_btn);

        buttonAddNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent AddNewsIntent = new Intent(AddNewsActivity.this, NewsActivity.class);
                startActivity(AddNewsIntent);
            }
        });
    }
}