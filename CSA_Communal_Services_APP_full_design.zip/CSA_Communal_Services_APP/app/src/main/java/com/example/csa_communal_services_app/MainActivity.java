package com.example.csa_communal_services_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button buttonLog, buttonReg, buttonNews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonReg = (Button) findViewById(R.id.main_reg_btn);
        buttonLog = (Button) findViewById(R.id.main_log_btn);
        buttonNews = (Button) findViewById(R.id.main_news_btn);

        buttonLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent LoginIntent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(LoginIntent);
            }
        });

        buttonReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent RegistrationIntent = new Intent(MainActivity.this, RegistrationActivity.class);
                startActivity(RegistrationIntent);
            }
        });

        buttonNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent NewsIntent = new Intent(MainActivity.this, NewsActivity.class);
                startActivity(NewsIntent);
            }
        });
    }
}