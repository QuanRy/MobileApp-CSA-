package com.example.csa_communal_services_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class AddWorkActivity extends AppCompatActivity {

    private String[] TypeWork = {"Уборка", "Опиливание", "Вывоз мусора", "Авария", "Полив", "Уборка снега"};

    private Button buttonAddWork;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_work);

        buttonAddWork = (Button) findViewById(R.id.add_news_btn);

        buttonAddWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent AddWorkIntent = new Intent(AddWorkActivity.this, NewsActivity.class);
                startActivity(AddWorkIntent);
            }
        });

        ArrayAdapter<String> TypeWorkAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, TypeWork);

        TypeWorkAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        Spinner spTypeWork = (Spinner) findViewById(R.id.spinnerTypeWork);

        spTypeWork.setAdapter (TypeWorkAdapter);

        spTypeWork.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l)
            {
                Toast.makeText(getBaseContext(), adapterView.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView)
            {

            }
        });
    }
}